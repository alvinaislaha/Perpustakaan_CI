<?php $this->load->view("/partial/header");?>
<?php $this->load->view("/partial/navbar");?>
<?php $this->load->view("/partial/top_navigation");?>
<?php $this->load->view($content);?>
<?php $this->load->view("/partial/footer");?>